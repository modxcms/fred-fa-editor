<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'The MIT License (MIT)

Copyright (c) 2018 MODX, LLC

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => '---------------------------------------
Fred FA Editor
---------------------------------------
Version: 1.0.0-beta2
Author: John Peca <john@modx.com>
---------------------------------------

To use the Font Awesome icon picker, change the value of the fred.icon_editor system setting in the Fred namespace to "FAEditor".',
    'changelog' => 'Changelog for Fred FA Editor.

Fred FA Editor 1.0.0-beta2
==============
- Add resolver to adjust IconEditor in system settings

Fred FA Editor 1.0.0-beta
==============
- Initial release.',
    'requires' => 
    array (
      'fred' => '>=1.0.0',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '5efac8c9a0ba0033cf68f0941a664840',
      'native_key' => 'fredfaeditor',
      'filename' => 'modNamespace/e8aab5971f92f19be5749e3f9b32d09d.vehicle',
      'namespace' => 'fredfaeditor',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'a967a51967b428f67309c2744f090aa0',
      'native_key' => NULL,
      'filename' => 'modCategory/eb3196c8d5bae506d82ab7467012809f.vehicle',
      'namespace' => 'fredfaeditor',
    ),
  ),
);