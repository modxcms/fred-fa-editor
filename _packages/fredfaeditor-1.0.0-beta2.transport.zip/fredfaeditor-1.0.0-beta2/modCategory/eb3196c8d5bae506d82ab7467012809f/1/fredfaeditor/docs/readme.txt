---------------------------------------
Fred FA Editor
---------------------------------------
Version: 1.0.0-beta2
Author: John Peca <john@modx.com>
---------------------------------------

To use the Font Awesome icon picker, change the value of the fred.icon_editor system setting in the Fred namespace to "FAEditor".