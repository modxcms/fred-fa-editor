<?php

$_lang['fredfaeditor.size'] = 'Size';
$_lang['fredfaeditor.fixed_width'] = 'Fixed Width';
$_lang['fredfaeditor.border'] = 'Border';
$_lang['fredfaeditor.pull'] = 'Pull';
$_lang['fredfaeditor.animation'] = 'Animation';
$_lang['fredfaeditor.preview'] = 'Preview';
$_lang['fredfaeditor.icon'] = 'Icon';
$_lang['fredfaeditor.none'] = 'None';
$_lang['fredfaeditor.pulse'] = 'Pulse';
$_lang['fredfaeditor.spin'] = 'Spin';
$_lang['fredfaeditor.default'] = 'Default';
$_lang['fredfaeditor.left'] = 'Left';
$_lang['fredfaeditor.right'] = 'Right';